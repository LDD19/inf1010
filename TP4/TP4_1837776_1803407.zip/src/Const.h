/**************************************************
 * Titre: Travail pratique #4 - Const.h
 * Date:28 Octobre 2017
 * Auteurs: Gabriel-Andrew Pollo-Guilbert, Si Da Li
**************************************************/
#ifndef CONST_H
#define CONST_H

typedef unsigned int uint_t;

#endif
