/**************************************************
 * Titre: Travail pratique #2 - Const.h
 * Date: Septembre 2017
 * Auteurs: Gabriel-Andrew Pollo-Guilbert, Si Da Li
**************************************************/

#ifndef CONST_H
#define CONST_H

typedef unsigned int uint_t;

const int MIN_CONCENTRATION_COULEUR = 0;
const int MAX_CONCENTRATION_COULEUR = UINT8_MAX;

#endif
