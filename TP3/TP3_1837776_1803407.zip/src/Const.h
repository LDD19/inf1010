/**************************************************
 * Titre: Travail pratique #3 - Const.h
 * Date:22 Octobre 2017
 * Auteurs: Gabriel-Andrew Pollo-Guilbert, Si Da Li
**************************************************/
#ifndef CONST_H
#define CONST_H

typedef unsigned int uint_t;

#endif
